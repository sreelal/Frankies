//
//  ViewController.swift
//  Breathe
//
//  Created by Sreelal H on 27/06/22.
//

import UIKit

class ViewController: UIViewController {
    
    enum ColorTypes {
        case OuterCircle
        case MiddleCircle
        case RippleCircle
        case ProgressCircle
        case StatusLabel
        case TimerLabel
        case CounterLabel
    }
    
    enum FontTypes {
        case CounterFont
        case StatusLabelFont
    }
    
    @IBOutlet weak var initCounterSwitch: UISwitch!
    @IBOutlet weak var focusDuration: UITextField!
    @IBOutlet weak var relaxDurationTxt: UITextField!
    @IBOutlet weak var initDuration: UITextField!
    @IBOutlet weak var exhaleHoldTxt: UITextField!
    @IBOutlet weak var exhaleTxt: UITextField!
    @IBOutlet weak var inhaleTxt: UITextField!
    @IBOutlet weak var inhaleHoldTxt: UITextField!
    @IBOutlet weak var breathingCountTxt: UITextField!
    @IBOutlet weak var statusFontSizeTxt: UITextField!
    @IBOutlet weak var counterFontSizeTxt: UITextField!

    @IBOutlet weak var progressCircleColorButton: UIButton!
    @IBOutlet weak var rippleCircleColorButton: UIButton!
    @IBOutlet weak var middleCircleColorButton: UIButton!
    @IBOutlet weak var outerCircleColorButton: UIButton!
    @IBOutlet weak var statusLabelColorButton: UIButton!
    @IBOutlet weak var timerLabelColorButton: UIButton!
    @IBOutlet weak var counterLabelColorButton: UIButton!
    @IBOutlet weak var counterFontButton: UIButton!
    @IBOutlet weak var statusFontButton: UIButton!

    private var selectedColorType: ColorTypes?
    private var selectedFontType: FontTypes?

    var breathConfig = BreathConfig()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onStartBreath(_ sender: Any) {
        performSegue(withIdentifier: "startBreathSegue2", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let brethongVC = segue.destination as? BreathingViewController {
            brethongVC.breathConfig = breathConfig
        }
    }
    
    func showErrorMessage(message: String) {
        let alert = UIAlertController(title: "Breath", message: message,
                                      preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func didChangeSwitch(_ sender: Any) {
        guard let switchControl = sender as? UISwitch else {
            return
        }
        switch switchControl.tag {
        case 111:
            breathConfig.showInitialisationCounter = switchControl.isOn
        case 222:
            breathConfig.relaxEnabled = switchControl.isOn
        case 333:
            breathConfig.focusEnabled = switchControl.isOn
        case 444:
            breathConfig.showTimer = switchControl.isOn
        case 555:
            breathConfig.showBreathProgress = switchControl.isOn
        case 666:
            breathConfig.showHoldProgressBar = switchControl.isOn
        case 777:
            breathConfig.showBreathCounter = switchControl.isOn
        default:
            return
        }
    }
    
    @IBAction func didChangeStepper(_ sender: Any) {
        
        guard let stepper = sender as? UIStepper else {
            return
        }
        let stepperValue = Int(stepper.value)
        switch stepper.tag {
        case 11:
            breathConfig.inititalisationCounterDuration = stepperValue
            initDuration.text = "\(stepperValue)"
        case 22:
            breathConfig.relaxDuration = stepperValue
            relaxDurationTxt.text = "\(stepperValue)"
        case 33:
            breathConfig.focusDuration = stepperValue
            focusDuration.text = "\(stepperValue)"
        case 44:
            breathConfig.breathInDuration = stepperValue
            inhaleTxt.text = "\(stepperValue)"
        case 55:
            breathConfig.breathInHoldDuration = stepperValue
            inhaleHoldTxt.text = "\(stepperValue)"
        case 66:
            breathConfig.breathOutDuration = stepperValue
            exhaleTxt.text = "\(stepperValue)"
        case 77:
            breathConfig.breathOutHoldDuration = stepperValue
            exhaleHoldTxt.text = "\(stepperValue)"
        case 88:
            breathConfig.cycles = stepperValue
            breathingCountTxt.text = "\(stepperValue)"
        case 99:
            breathConfig.statusFontSize = stepperValue
            statusFontSizeTxt.text = "\(stepperValue)"
            self.selectedFontType = .StatusLabelFont
            updateFont(descriptor: statusFontButton.titleLabel?.font.fontDescriptor ?? UIFontDescriptor(name: "system", size: 20))
            
        case 1010:
            breathConfig.counterFontSize = stepperValue
            counterFontSizeTxt.text = "\(stepperValue)"
            self.selectedFontType = .CounterFont
            updateFont(descriptor: counterFontButton.titleLabel?.font.fontDescriptor ?? UIFontDescriptor(name: "system", size: 20))

        default:
            return
        }
    }
    
    @IBAction func didSelectColor(_ sender: Any) {
        
        guard let button = sender as? UIButton else {
            return
        }
        var selectedColor = UIColor.clear
        switch button.tag {
        case 1111:
            self.selectedColorType = .OuterCircle
            selectedColor = breathConfig.outerCircleColor
        case 2222:
            self.selectedColorType = .MiddleCircle
            selectedColor = breathConfig.middleCircleColor
        case 3333:
            self.selectedColorType = .RippleCircle
            selectedColor = breathConfig.rippleCircleColor
        case 4444:
            self.selectedColorType = .ProgressCircle
            selectedColor = breathConfig.progressCircleColor
        case 5555:
            self.selectedColorType = .StatusLabel
            selectedColor = breathConfig.statusLabelColor
        case 6666:
            self.selectedColorType = .TimerLabel
            selectedColor = breathConfig.timerLabelColor
        case 7777:
            self.selectedColorType = .CounterLabel
            selectedColor = breathConfig.counterLabelColor
        default:
            return
        }
        showColorPicker(with: selectedColor)
    }
    
    @IBAction func didSelectFont(_ sender: Any) {
        
        guard let button = sender as? UIButton else {
            return
        }
        switch button.tag {
        case 11111:
            self.selectedFontType = .CounterFont
        case 22222:
            self.selectedFontType = .StatusLabelFont
        default:
            return
        }
        showFontPicker()
    }
    
    func showFontPicker() {
        let fontConfig = UIFontPickerViewController.Configuration()
        fontConfig.includeFaces = true
        let fontPicker = UIFontPickerViewController(configuration: fontConfig)
        fontPicker.delegate = self
        self.present(fontPicker, animated: true, completion: nil)
    }
    
    func showColorPicker(with selectedColor: UIColor) {
        let picker = UIColorPickerViewController()
        picker.selectedColor = selectedColor
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }
    
    func updateColor(selectedColor: UIColor) {
        guard let colorType = self.selectedColorType else { return }
        switch colorType {
        case .OuterCircle:
            outerCircleColorButton.backgroundColor = selectedColor
            breathConfig.outerCircleColor = selectedColor
        case .MiddleCircle:
            middleCircleColorButton.backgroundColor = selectedColor
            breathConfig.middleCircleColor = selectedColor
        case .RippleCircle:
            rippleCircleColorButton.backgroundColor = selectedColor
            breathConfig.rippleCircleColor = selectedColor
        case .ProgressCircle:
            progressCircleColorButton.backgroundColor = selectedColor
            breathConfig.progressCircleColor = selectedColor
        case .StatusLabel:
            statusLabelColorButton.backgroundColor = selectedColor
            breathConfig.statusLabelColor = selectedColor
        case .TimerLabel:
            timerLabelColorButton.backgroundColor = selectedColor
            breathConfig.timerLabelColor = selectedColor
        case .CounterLabel:
            counterLabelColorButton.backgroundColor = selectedColor
            breathConfig.counterLabelColor = selectedColor
        }
    }
    
    func updateFont(descriptor: UIFontDescriptor) {
        guard let fontType = self.selectedFontType else { return }
        switch fontType {
        case .CounterFont:
            let counterFont = UIFont(descriptor: descriptor, size: CGFloat(self.breathConfig.counterFontSize))
            counterFontButton.titleLabel?.font = counterFont
            breathConfig.counterLabelFont = counterFont
        case .StatusLabelFont:
            let statusFont = UIFont(descriptor: descriptor, size: CGFloat(self.breathConfig.statusFontSize))
            statusFontButton.titleLabel?.font = statusFont
            breathConfig.statusLabelFont = statusFont
        }
    }
}

extension ViewController: UIColorPickerViewControllerDelegate {
    //  Called once you have finished picking the color.
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        self.updateColor(selectedColor: viewController.selectedColor)
    }
    
    //  Called on every color selection done in the picker.
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        self.updateColor(selectedColor: viewController.selectedColor)
    }
}

extension ViewController: UIFontPickerViewControllerDelegate {
    
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        guard let descriptor = viewController.selectedFontDescriptor else { return }
        self.updateFont(descriptor: descriptor)
        self.dismiss(animated: true, completion: nil)
    }
}

