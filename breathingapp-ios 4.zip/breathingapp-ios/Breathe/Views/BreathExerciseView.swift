//
//  BreathExerciseView.swift
//  Breathe
//
//  Created by Sreelal H on 27/06/22.
//

import UIKit
import Combine

class BreathExerciseView: BaseXibView {
    
    @IBOutlet weak var counterLabel: UILabel!
    @IBOutlet weak var containerView: UIView!
    
    private var outerView: UIView?
    private let outerLayer = CAShapeLayer()
    private let middleLayer = CAShapeLayer() // Layer which animated to center while initializations
    private let breathingLayer = CAShapeLayer()
    private var progressLayer = CAShapeLayer() // To show cycle progress
    private var timer: Timer?
    private var initializeCounter = 5
    private var breathCounter = 0
    private var timerCallbackHandler: (() -> Void)?
    private var progressStartAngle = -0.25 * 2 * .pi
    private var progressEndAngle = (-0.25 * 2 * .pi) + (2 * .pi)
    @IBInspectable var outerCircleColor: UIColor?
    @IBInspectable var outerCircleBorderColor: UIColor?
    @IBInspectable var preparationCircleColor: UIColor?
    @IBInspectable var preparationCircleBorderColor: UIColor?
    @IBInspectable var breathCircleColor: UIColor?
    @IBInspectable var breathCircleBorderColor: UIColor?
    @IBInspectable var progressColor: UIColor?
    
    var counterFont: UIFont?
    var counterFontSize: CGFloat = 20.0
    var counterLabelColor: UIColor = .black

    var timerSubscription: AnyCancellable?
    let completedActivity = PassthroughSubject<Bool, Never>()
    var focusCompletionDelegate: (() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        //        drawAllCircles()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func layoutSubviews() {
    }
    
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        print("Draw here")
        drawAllCircles()
        self.addObserver(self, forKeyPath: "containerView.bounds", options: .new, context: nil)
    }
    
    private func drawAllCircles() {
        self.layoutIfNeeded()
        applyStyles()
        //drawOuterCircle()
        drawOuterCircle()
        //Add Preparation layer
        drawPreparationsCircle()
        //Add Breathing layer
        drawBreathingCircle()
        //Add Progress layer
        drawProgressCircle()
    }
    
    private func adjustAllLayerBounds() {
        let size = min(containerView.bounds.size.height, containerView.bounds.size.width)
        let circularPath = UIBezierPath(arcCenter: .zero, radius: size/2, startAngle: 0, endAngle: CGFloat.pi * 2, clockwise: true)
        outerLayer.path = circularPath.cgPath
        outerLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        
        middleLayer.path = outerLayer.path
        middleLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        
        breathingLayer.path = outerLayer.path
        breathingLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        
        let progressPath = UIBezierPath(arcCenter: .zero, radius: (size/2) + 2, startAngle: progressStartAngle, endAngle: progressEndAngle, clockwise: true)
        progressLayer.path = progressPath.cgPath
    }
    
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "containerView.bounds" {
            adjustAllLayerBounds()
            return
        }
        super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
    }
    
    private func applyStyles() {
        counterLabel.font = counterFont?.withSize(counterFontSize)
        counterLabel.textColor = counterLabelColor
    }
    
    private func drawOuterCircle() {
        
        if outerLayer.superlayer != nil {
            outerLayer.removeFromSuperlayer()
        }
        let size = min(containerView.bounds.size.height, containerView.bounds.size.width)
        let circularPath = UIBezierPath(arcCenter: .zero, radius: size/2, startAngle: 0, endAngle: CGFloat.pi * 2, clockwise: true)
        outerLayer.path = circularPath.cgPath
        outerLayer.strokeColor = outerCircleBorderColor?.cgColor ?? UIColor.black.cgColor
        outerLayer.fillColor = outerCircleColor?.cgColor ?? UIColor.systemGray6.cgColor
        outerLayer.lineWidth = 1.0
        outerLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        containerView.layer.insertSublayer(outerLayer, below: counterLabel.layer)
    }
    
    func drawPreparationsCircle() {
        if middleLayer.superlayer != nil {
            middleLayer.removeFromSuperlayer()
        }
        middleLayer.path = outerLayer.path
        middleLayer.strokeColor = preparationCircleBorderColor?.cgColor ?? UIColor.black.cgColor
        middleLayer.fillColor = preparationCircleColor?.cgColor ?? UIColor.systemGray6.cgColor
        middleLayer.lineWidth = 1.0
        middleLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        containerView.layer.insertSublayer(middleLayer, below: counterLabel.layer)
    }
    
    func drawBreathingCircle() {
        if breathingLayer.superlayer != nil {
            breathingLayer.removeFromSuperlayer()
        }
        breathingLayer.path = outerLayer.path
        breathingLayer.strokeColor = breathCircleBorderColor?.cgColor ?? UIColor.black.cgColor
        breathingLayer.fillColor = breathCircleColor?.cgColor ?? UIColor.systemGray6.cgColor
        breathingLayer.lineWidth = 1.0
        breathingLayer.position = self.containerView.convert(self.containerView.center, from: self.containerView.superview)
        containerView.layer.insertSublayer(breathingLayer, below: middleLayer)
        self.breathingLayer.setAffineTransform(CGAffineTransform(scaleX: 0.5, y: 0.5))
        breathingLayer.isHidden = true
    }
    
    func drawProgressCircle() {
        if progressLayer.superlayer != nil {
            progressLayer.removeFromSuperlayer()
        }
        
        let size = min(containerView.bounds.size.height, containerView.bounds.size.width)
        let circularPath = UIBezierPath(arcCenter: .zero, radius: (size/2) + 2, startAngle: progressStartAngle, endAngle: progressEndAngle, clockwise: true)
        progressLayer.path = circularPath.cgPath
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineCap = .round
        progressLayer.lineWidth = 2.0
        progressLayer.strokeEnd = 0.0
        progressLayer.strokeColor = self.progressColor?.cgColor ?? UIColor.black.cgColor
        // added progressLayer to layer
        outerLayer.insertSublayer(progressLayer, above: breathingLayer)
    }
    
    deinit {
//        removeAllObservers()
        print("Removing Breath View")
    }
    
    func removeAllObservers() {
        self.removeObserver(self, forKeyPath: "containerView.bounds")
    }
}

extension BreathExerciseView {
    
    private func startCounterTimer(with countDownValue: Int, updateTimerLabel: Bool, timerUpdate: ((Int) -> Void)? = nil , completion: @escaping () -> Void) {
        var intializationStartValue = countDownValue
        let timer = Timer.publish(every: 1.0, on: .main, in: .common)
            .autoconnect()
        let initial = Just(Date.init()) // to fire timer instantly
        timerSubscription = timer.merge(with: initial).sink { completion in
            print("data stream completion : \(completion)")
        } receiveValue: { [unowned self] (timestamp) in
            DispatchQueue.main.async {
                if intializationStartValue > 0 {
                    if let updateTimerHandler = timerUpdate {
                        updateTimerHandler(intializationStartValue)
                    }
                    if updateTimerLabel {
                        self.counterLabel.text = "\(intializationStartValue)"
                    }
                    intializationStartValue -= 1
                } else {
                    timer.upstream.connect().cancel()
                    timerSubscription?.cancel()
                    completion()
                }
            }
        }
    }
    
    func startInitializationCounter(countDownValue: Int, completion: @escaping () -> Void) {
        startCounterTimer(with: countDownValue, updateTimerLabel: true) {
            self.counterLabel.text = ""
            completion()
        }
    }
    
    func startRelaxation(relaxDuration: Int, completion: @escaping () -> Void) {
        startCounterTimer(with: relaxDuration, updateTimerLabel: false, completion: completion)
    }
    
    func startFocus(focusDuration: Int, completion: @escaping () -> Void) {
        self.focusCompletionDelegate = completion
        DispatchQueue.main.async {
            let animation = CAKeyframeAnimation(keyPath: "transform.scale")
            animation.values = [1.0, 0.5, 0.75, 0.5]
            animation.keyTimes = [0, 0.5, 0.75, 1]
            animation.duration = CFTimeInterval(focusDuration)
            animation.isRemovedOnCompletion = false
            animation.delegate = self
            self.middleLayer.setAffineTransform(CGAffineTransform(scaleX: 0.5, y: 0.5))
            self.middleLayer.add(animation, forKey: nil)
        }
    }
    
    func performBreath(isBreathIn: Bool, breathDuration: Int, showTimer: Bool, completion: @escaping () -> Void) {
        DispatchQueue.main.async { [unowned self] in
            self.breathingLayer.isHidden = false
            self.middleLayer.setAffineTransform(CGAffineTransform(scaleX: 0.5, y: 0.5))
            breathingLayer.removeAllAnimations()
            CATransaction.begin()
            let duration = CFTimeInterval(breathDuration)
            let rippleAnimation = CABasicAnimation(keyPath: "transform.scale")
            rippleAnimation.fromValue = isBreathIn ? 0.5 : 1
            rippleAnimation.toValue = isBreathIn ? 1 : 0.5
            rippleAnimation.duration = duration
            self.breathingLayer.setAffineTransform(CGAffineTransform(scaleX: isBreathIn ? 1 : 0.5, y: isBreathIn ? 1 : 0.5))
            if !showTimer {
                // call completion block on animation end
                CATransaction.setCompletionBlock {
                    completion()
                }
            } else {
                startCounterTimer(with: breathDuration, updateTimerLabel: true, timerUpdate: nil, completion: completion)
            }
     
            breathingLayer.add(rippleAnimation, forKey: "rippleAnimation")
            CATransaction.commit()
        }
    }
    
    func performHold(isBreathIn: Bool, holdDuration: Int, timerUpdateHandler: ((Int) -> Void)?, completion: @escaping () -> Void) {
        DispatchQueue.main.async { [unowned self] in
            self.counterLabel.text = "II"
        }
        startCounterTimer(with: holdDuration, updateTimerLabel: false, timerUpdate: timerUpdateHandler, completion: completion)
    }
    
    func updateProgressAnimation(duration: TimeInterval, currentCycleCount: Int, totalCyle: Int) {
        DispatchQueue.main.async { [unowned self] in
            let circularProgressAnimation = CABasicAnimation(keyPath: "strokeEnd")
            circularProgressAnimation.duration = duration
            circularProgressAnimation.fromValue = progressLayer.strokeEnd
            let toValue = Float((1.0/Float(totalCyle)) * Float(currentCycleCount))
            print("Draw to : \(toValue)")
            circularProgressAnimation.toValue = toValue
            progressLayer.strokeEnd = CGFloat(toValue)
            circularProgressAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            circularProgressAnimation.isRemovedOnCompletion = false
            circularProgressAnimation.fillMode = .forwards
            progressLayer.add(circularProgressAnimation, forKey: "animateprogress")
        }
    }
    
    func updateIdleState() {
        DispatchQueue.main.async { [unowned self] in
            self.counterLabel.text = ""
        }
    }
    
    func stopAllBreathingProcess() {
        removeAllObservers()
        timerSubscription?.cancel()
    }
}

extension BreathExerciseView: CAAnimationDelegate {
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        if let completionHandler = self.focusCompletionDelegate {
            completionHandler()
        }
    }
}
