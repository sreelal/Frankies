//
//  BaseXibView.swift
//  Breathe
//
//  Created by Sreelal H on 27/06/22.
//

import UIKit

class BaseXibView: UIView {

    public var view: UIView!
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        xibSetup()
    }
    
    private func xibSetup() {
        view = loadViewFromNib()
        view.frame = bounds
        self.backgroundColor = .clear
        view.backgroundColor = .clear
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    private func loadViewFromNib() -> UIView {
        let className = String(describing: type(of: self))
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: className, bundle: bundle)
        guard let instatiateView = nib.instantiate(withOwner: self, options: nil).first as? UIView else {
            fatalError("Cannot instantiate View from nib")
        }
        return instatiateView
    }
}
