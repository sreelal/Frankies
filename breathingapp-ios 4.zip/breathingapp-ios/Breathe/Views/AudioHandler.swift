//
//  SpeechHandler.swift
//  Breathe
//
//  Created by Sreelal H on 18/07/22.
//

import UIKit
import AVFoundation

class AudioHandler: NSObject {
    var player: AVAudioPlayer?
    
    func speak(text: String?, speed: Float) {
        guard let speechText = text else { return }
        let utterance = AVSpeechUtterance(string: speechText)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-CA")
        utterance.rate = speed
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
    
    func playAudio(audioFile: String) {
        guard let path = Bundle.main.path(forResource: "breathe", ofType:"mp3") else {
            return
        }
        let url = URL(fileURLWithPath: path)
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func stopAudio() {
        player?.stop()
        player = nil
    }
    
    func isPlayingAudio() -> Bool {
        return player?.isPlaying ?? false
    }
}
