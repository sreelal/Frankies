//
//  BreathingViewController.swift
//  Breathe
//
//  Created by Sreelal H on 28/07/22.
//

import UIKit
import Combine

struct BreathConfig {
    var showInitialisationCounter: Bool = true
    var inititalisationCounterDuration: Int = 4
    var relaxEnabled: Bool = true
    var relaxDuration: Int = 5
    var focusEnabled: Bool = true
    var focusDuration: Int = 5
    var breathInDuration: Int = 5
    var breathInHoldDuration: Int = 5
    var breathOutDuration: Int = 5
    var breathOutHoldDuration: Int = 5
    var cycles: Int = 1
    var showTimer: Bool = true
    var showBreathProgress: Bool = true // To show the progress around the circle
    var showHoldProgressBar: Bool = true // To show or hide the progress bar while hold
    var showBreathCounter: Bool = true // To show or hide the progress bar while hold
    var outerCircleColor: UIColor = .opaqueSeparator
    var middleCircleColor: UIColor = .darkGray
    var rippleCircleColor: UIColor = .lightGray
    var progressCircleColor: UIColor = .systemBlue
    var statusLabelFont: UIFont = UIFont(name: "Avenir", size: 20) ?? .systemFont(ofSize: 40)
    var counterLabelFont: UIFont = UIFont(name: "Avenir", size: 40) ?? .systemFont(ofSize: 40)
    var statusFontSize: Int = 20
    var counterFontSize: Int = 40
    var timerLabelColor: UIColor = .darkGray
    var statusLabelColor: UIColor = .systemBlue
    var counterLabelColor: UIColor = .lightGray

}

class BreathingViewController: UIViewController {
    
    struct Constants {
        static let exhale = "Breathe Out"
        static let inhale = "Breathe In"
        static let hold = "Hold"
        static let relax = "Relax and get comfortable"
        static let focus = "Focus on your breathing"
        static let welldone = "Well done"
        static let speakSpeed = Float(0.1)
    }
    
    lazy var audioHandler = AudioHandler()
    @IBOutlet weak var breathView: BreathExerciseView?
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var holdProgress: UIProgressView!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var breathViewwidthConstraint: NSLayoutConstraint!
    private var countDownTimer = 0
    private var timer: Timer?
    var breathConfig: BreathConfig?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Start audio
        breathConfig = BreathConfig()
        if !audioHandler.isPlayingAudio() {
            audioHandler.playAudio(audioFile: "breathe")
        }
        self.setupUI()
        self.startBreathProcess()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        breathView?.stopAllBreathingProcess()
        breathView = nil
        audioHandler.stopAudio()
        stopOverallTimer()
    }
    
    deinit {
        print("Removing Breath VC")
    }
    
    func setupUI() {
        guard let breathConfig = breathConfig else { return }
        guard let breathView = breathView else { return }
        timerLabel.text = ""
        holdProgress.isHidden = true
        holdProgress.progress = 0
        breathView.outerCircleColor = breathConfig.outerCircleColor
        breathView.outerCircleBorderColor = breathConfig.outerCircleColor
        breathView.preparationCircleColor = breathConfig.middleCircleColor
        breathView.preparationCircleBorderColor = breathConfig.middleCircleColor
        breathView.breathCircleColor = breathConfig.rippleCircleColor
        breathView.breathCircleBorderColor = breathConfig.rippleCircleColor
        breathView.progressColor = breathConfig.progressCircleColor
        breathView.counterFont = breathConfig.counterLabelFont
        breathView.counterFontSize = CGFloat(breathConfig.counterFontSize)
        breathView.counterLabelColor = breathConfig.counterLabelColor
        titleLabel.font = breathConfig.statusLabelFont.withSize(CGFloat(breathConfig.statusFontSize))
        timerLabel.font = breathConfig.statusLabelFont.withSize(CGFloat(breathConfig.statusFontSize))
        titleLabel.textColor = breathConfig.statusLabelColor
        timerLabel.textColor = breathConfig.timerLabelColor
    }
    
    func startBreathProcess() {
        guard let breathConfiguration = breathConfig else { return }
        let semaphore = DispatchSemaphore(value: 1)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let strogSelf = self else { return }
            let dispatchGroup = DispatchGroup()
            
            // Initialisation counter
            if breathConfiguration.showInitialisationCounter {
                dispatchGroup.enter()
                semaphore.wait()
                strogSelf.breathView?.startInitializationCounter(countDownValue: breathConfiguration.inititalisationCounterDuration) {
                    dispatchGroup.leave()
                    semaphore.signal()
                }
            }
            
            // Relaxation counter
            if breathConfiguration.relaxEnabled {
                dispatchGroup.enter()
                semaphore.wait()
                strogSelf.updateRelaxationUI()
                strogSelf.breathView?.startRelaxation(relaxDuration: breathConfiguration.relaxDuration) {
                    dispatchGroup.leave()
                    semaphore.signal()
                }
            }
            
            //Focus
            if breathConfiguration.focusEnabled {
                dispatchGroup.enter()
                semaphore.wait()
                strogSelf.updateFocusUI()
                strogSelf.breathView?.startFocus(focusDuration: breathConfiguration.focusDuration) {
                    dispatchGroup.leave()
                    semaphore.signal()
                }
            }
            
            //Start Breathing
            let totalBreathings = breathConfiguration.cycles * 2
            var isBreathIn = true
            for i in 0 ..< totalBreathings {
                // 1. Start with breathIn
                // 2. perform breathIn hold
                // 3. perform breathOut
                // 4. perform breathOut hold
                
                // Start Breathin or Breathout
                dispatchGroup.enter()
                semaphore.wait()
                if breathConfiguration.showTimer {
                    strogSelf.startOverallTimer()
                }
                if breathConfiguration.showBreathProgress {
                    strogSelf.breathView?.updateProgressAnimation(duration: 1.0, currentCycleCount: i + 1, totalCyle: totalBreathings)
                }
                let breathDuration = isBreathIn ? breathConfiguration.breathInDuration : breathConfiguration.breathOutDuration
                strogSelf.updateBreathUI(isBreathIn: isBreathIn, speakText: (breathDuration > 0))
                strogSelf.breathView?.performBreath(isBreathIn: isBreathIn, breathDuration: breathDuration, showTimer: breathConfiguration.showBreathCounter) {
                    dispatchGroup.leave()
                    semaphore.signal()
                }
                
                // Start Breathin or Breathout Hold
                dispatchGroup.enter()
                semaphore.wait()
                let holdDuration = isBreathIn ? breathConfiguration.breathInHoldDuration : breathConfiguration.breathOutHoldDuration
                strogSelf.updateHoldUI(speakText: (holdDuration > 0))
                strogSelf.breathView?.performHold(isBreathIn: isBreathIn, holdDuration: holdDuration) { updatedTime in
                    print("\(updatedTime)")
                    if breathConfiguration.showHoldProgressBar {
                        strogSelf.updateUIForHoldTimer(value: updatedTime, maxValue: holdDuration)
                    }
                } completion: {
                    dispatchGroup.leave()
                    semaphore.signal()
                    isBreathIn = !isBreathIn
                    strogSelf.stopHoldTimer()
                }
            }
            
            dispatchGroup.wait()
            DispatchQueue.main.async { [unowned self] in
                print("Completed All process")
                strogSelf.stopBreathingUI()
            }
        }
    }
    
    func updateRelaxationUI() {
        DispatchQueue.main.async { [unowned self] in
            self.audioHandler.speak(text: Constants.relax, speed: Constants.speakSpeed)
            self.titleLabel.text = Constants.relax
        }
    }
    
    func updateFocusUI() {
        DispatchQueue.main.async { [unowned self] in
            self.audioHandler.speak(text: Constants.focus, speed: Constants.speakSpeed)
            self.titleLabel.text = Constants.focus
        }
    }
    
    func updateBreathUI(isBreathIn: Bool, speakText: Bool) {
        DispatchQueue.main.async { [unowned self] in
            holdProgress.isHidden = true
            holdProgress.progress = 0
            let title = isBreathIn ? Constants.inhale : Constants.exhale
            if speakText {
                audioHandler.speak(text: title, speed: Constants.speakSpeed)
            }
            self.titleLabel.text = title
        }
    }
    
    func updateHoldUI(speakText: Bool) {
        if speakText {
            DispatchQueue.main.async { [unowned self] in
                audioHandler.speak(text: Constants.hold, speed: Constants.speakSpeed)
            }
        }
    }
    
    func updateUIForHoldTimer(value: Int, maxValue: Int) {
        DispatchQueue.main.async { [unowned self] in
            holdProgress.isHidden = false
            holdProgress.progress = Float(maxValue-value+2)/Float(maxValue)
        }
    }
    
    func stopHoldTimer() {
        DispatchQueue.main.async { [unowned self] in
            holdProgress.isHidden = true
        }
    }
    
    func stopBreathingUI() {
        DispatchQueue.main.async { [unowned self] in
            self.audioHandler.speak(text: Constants.welldone, speed: Constants.speakSpeed)
            self.titleLabel.text = Constants.welldone
            self.stopOverallTimer()
            self.breathView?.updateIdleState()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {[ unowned self] in
                self.audioHandler.stopAudio()
            })
        }
    }
    
    func startOverallTimer() {
        guard let breathConfiguration = breathConfig else { return }
        DispatchQueue.main.async { [unowned self] in
            if timer?.isValid ?? false {
                return
            }
            countDownTimer = (breathConfiguration.breathInDuration + breathConfiguration.breathOutDuration + breathConfiguration.breathOutHoldDuration + breathConfiguration.breathInHoldDuration) * breathConfiguration.cycles
            timer = Timer.scheduledTimer(timeInterval: 1.0,
                                         target: self,
                                         selector: #selector(self.timerHandler(_:)), userInfo: nil, repeats: true)
        }
    }
    
    @objc func timerHandler(_ timer: Timer) {
        DispatchQueue.main.async { [unowned self] in
            self.timerLabel.isHidden = false
            self.countDownTimer -= 1
            if self.countDownTimer < 0 {
                return
            }
            self.timerLabel.text = self.countDownTimer.timeString
        }
    }
    
    func stopOverallTimer() {
        DispatchQueue.main.async { [unowned self] in
            self.timerLabel.text = ""
            if timer?.isValid ?? false {
                timer?.invalidate()
            }
        }
    }
}

extension Int {
    var timeString: String {
        let h = self / 3600
        let m = (self % 3600) / 60
        let s = (self % 3600) % 60
        return h > 0 ? String(format: "%1d:%02d:%02d", h, m, s) : String(format: "%1d:%02d", m, s)
    }
}
